@echo off
echo Instalando la copia automatica de ALBARANES TIENDA...
if not exist "C:\ALBTIEND" md "C:\ALBTIEND"
if not exist "C:\ALBTIEND\ENVIADOS" md "C:\ALBTIEND\ENVIADOS"
copy /y "%~dp0copia_albtiend.bat" "C:\ALBTIEND\" >nul
copy /y "%~dp0oculto.vbs" "C:\ALBTIEND\" >nul
schtasks /create /tn "Copia ALBTIEND" /tr "wscript.exe \"C:\ALBTIEND\oculto.vbs\"" /sc minute /mo 5 /f
if errorlevel 1 (
  echo ERROR: no se pudo crear la tarea programada.
  pause
  exit /b
)
call "C:\ALBTIEND\copia_albtiend.bat"
echo.
echo Listo. Cada 5 minutos se copiaran los albaranes nuevos a V:\SERVIDORW10\ALBTIEND.
echo El registro de lo copiado queda en C:\ALBTIEND\registro.txt
pause
