@echo off
rem Copia los albaranes de la tienda (T*.TXT) de Google Drive a V:\SERVIDORW10\ALBTIEND
rem Lo ejecuta Windows solo cada 5 minutos (tarea "Copia ALBTIEND").

set "ORIGEN=G:\Mi unidad\EXPORTACION PROGRAMA"
set "DESTINO=\\Servidor-i7\servidor\SERVIDORW10\ALBTIEND"
set "ENVIADOS=C:\ALBTIEND\ENVIADOS"
set "REGISTRO=C:\ALBTIEND\registro.txt"

if not exist "%ORIGEN%\" exit /b
if not exist "%DESTINO%\" set "DESTINO=V:\SERVIDORW10\ALBTIEND"
if not exist "%DESTINO%\" exit /b
if not exist "%ENVIADOS%\" md "%ENVIADOS%"

rem Solo ficheros con nombre MS-DOS tipo T0000012.TXT (T + numero de albaran)
for /f "delims=" %%F in ('dir /b /a-d "%ORIGEN%\T*.TXT" 2^>nul ^| findstr /r /i "^T[0-9][0-9][0-9][0-9][0-9][0-9][0-9]\.TXT$"') do (
  if not exist "%ENVIADOS%\%%F" (
    copy /y "%ORIGEN%\%%F" "%DESTINO%\%%F" >nul && (
      copy /y "%ORIGEN%\%%F" "%ENVIADOS%\%%F" >nul
      >>"%REGISTRO%" echo %date% %time% copiado %%F
    )
  )
)
