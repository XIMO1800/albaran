CreateObject("WScript.Shell").Run """C:\ALBTIEND\copia_albtiend.bat""", 0, False
